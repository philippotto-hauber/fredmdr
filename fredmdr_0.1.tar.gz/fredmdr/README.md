# fredmdr
R implementation of the McCracken and Ng codes to handle FRED-MD
